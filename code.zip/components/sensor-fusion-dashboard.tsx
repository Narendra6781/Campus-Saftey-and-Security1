"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { ResponsiveContainer, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts"

export default function SensorFusionDashboard() {
  const [sensorData] = useState([
    { name: "CCTV", value: 98, status: "active", color: "#8b5cf6" },
    { name: "Wi-Fi Density", value: 85, status: "active", color: "#6366f1" },
    { name: "Motion Sensors", value: 92, status: "active", color: "#a855f7" },
    { name: "Access Control", value: 78, status: "active", color: "#d946ef" },
  ])

  const [radarData] = useState([
    { sensor: "CCTV", confidence: 98 },
    { sensor: "Wi-Fi", confidence: 85 },
    { sensor: "Motion", confidence: 92 },
    { sensor: "Access", confidence: 78 },
    { sensor: "Acoustic", confidence: 65 },
  ])

  const [fusionScore, setFusionScore] = useState(87)

  useEffect(() => {
    const interval = setInterval(() => {
      setFusionScore((prev) => {
        const newScore = prev + (Math.random() - 0.5) * 4
        return Math.max(60, Math.min(99, newScore))
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-6">Real-Time Sensor Fusion</h2>

        {/* Fusion Score */}
        <Card className="glow-accent p-8 border-accent/20 bg-gradient-to-br from-accent/10 to-card/50 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg text-muted-foreground mb-2">Overall Fusion Score</h3>
              <p className="text-5xl font-bold text-accent">{fusionScore.toFixed(0)}/100</p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 relative">
                <div className="absolute inset-0 rounded-full border-4 border-accent/20" />
                <div
                  className="absolute inset-0 rounded-full border-4 border-accent"
                  style={{
                    clipPath: `polygon(0 0, ${fusionScore}% 0, ${fusionScore}% 100%, 0 100%)`,
                  }}
                />
                <div className="absolute inset-2 rounded-full bg-background flex items-center justify-center">
                  <span className="text-lg font-bold text-accent">{Math.round(fusionScore)}%</span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Sensor Status */}
          <Card className="glow-accent-sm border-accent/20 bg-card/50 p-6">
            <h3 className="font-semibold text-lg mb-4">Active Sensors</h3>
            <div className="space-y-3">
              {sensorData.map((sensor, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{sensor.name}</span>
                    <span className="font-mono text-accent">{sensor.value}%</span>
                  </div>
                  <div className="w-full bg-card/50 rounded-full h-2 overflow-hidden border border-border">
                    <div className="h-full bg-accent/70 transition-all" style={{ width: `${sensor.value}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Confidence Radar */}
          <Card className="glow-accent-sm border-accent/20 bg-card/50 p-6">
            <h3 className="font-semibold text-lg mb-4">Multi-Sensor Confidence</h3>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(139, 92, 246, 0.2)" />
                <PolarAngleAxis dataKey="sensor" stroke="rgba(139, 92, 246, 0.5)" />
                <PolarRadiusAxis stroke="rgba(139, 92, 246, 0.3)" />
                <Radar name="Confidence" dataKey="confidence" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Fusion Details */}
        <Card className="glow-accent-sm border-accent/20 bg-card/50 p-6">
          <h3 className="font-semibold text-lg mb-4">Sensor Integration Details</h3>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div>
              <h4 className="font-semibold text-accent mb-2">CCTV Analysis</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• 4 persons detected in frame</li>
                <li>• Group formation detected</li>
                <li>• Restricted zone alert: YES</li>
                <li>• Confidence: 98%</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-accent mb-2">Wi-Fi & Motion Correlation</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Wi-Fi hotspots: 6 devices</li>
                <li>• Motion intensity: HIGH</li>
                <li>• Spike correlation: 0.92</li>
                <li>• Badge access: None recorded</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
