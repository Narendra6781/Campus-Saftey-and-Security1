"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import VideoDetectionPanel from "./video-detection-panel"
import AnomalyVisualization from "./anomaly-visualization"
import SensorFusionDashboard from "./sensor-fusion-dashboard"
import AlertManager from "./alert-manager"
import LangGraphPipeline from "./langgraph-pipeline"

type TabType = "overview" | "detection" | "anomaly" | "sensors" | "alerts"

export default function DashboardPage({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<TabType>("overview")

  const tabs = [
    { id: "overview", label: "System Overview" },
    { id: "detection", label: "Video Detection" },
    { id: "anomaly", label: "Anomaly Detection" },
    { id: "sensors", label: "Sensor Fusion" },
    { id: "alerts", label: "Alerts" },
  ] as const

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold">CampusGuard AI Dashboard</h1>
          </div>
          <div className="text-xs text-muted-foreground">
            Status: <span className="text-green-400 font-semibold pulse">● Active</span>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="border-b border-border bg-card/30 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex overflow-x-auto gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`px-4 py-3 text-sm font-medium transition-all border-b-2 ${
                  activeTab === tab.id
                    ? "border-accent text-accent"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "overview" && <LangGraphPipeline />}
        {activeTab === "detection" && <VideoDetectionPanel />}
        {activeTab === "anomaly" && <AnomalyVisualization />}
        {activeTab === "sensors" && <SensorFusionDashboard />}
        {activeTab === "alerts" && <AlertManager />}
      </main>
    </div>
  )
}
