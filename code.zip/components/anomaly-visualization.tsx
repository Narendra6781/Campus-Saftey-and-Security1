"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts"

export default function AnomalyVisualization() {
  const [anomalyData, setAnomalyData] = useState(
    Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      anomalyScore: Math.random() * 0.4 + (i % 6 === 0 ? 0.7 : 0),
      threshold: 0.7,
    })),
  )

  const [detectionCode] = useState(
    `
# Python Anomaly Detection Module
if people_count >= 3 and area == "restricted":
    risk_score = 0.85
    timestamp = datetime.now()
    send_alert("Group Detected", risk_score)
elif unusual_movement_pattern:
    risk_score = 0.65
    send_alert("Anomalous Behavior", risk_score)
  `.trim(),
  )

  useEffect(() => {
    const interval = setInterval(() => {
      setAnomalyData((prev) => {
        const newData = [...prev.slice(1)]
        const lastScore = prev[prev.length - 1].anomalyScore

        let newScore = Math.max(0, Math.min(1, lastScore + (Math.random() - 0.5) * 0.15))
        if (Math.random() > 0.92) newScore = Math.min(1, 0.85 + Math.random() * 0.15)

        newData.push({
          time: `${new Date().getHours()}:${String(new Date().getMinutes()).padStart(2, "0")}`,
          anomalyScore: newScore,
          threshold: 0.7,
        })

        return newData
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const currentAnomaly = anomalyData[anomalyData.length - 1]?.anomalyScore || 0
  const isAlert = currentAnomaly > 0.7

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-6">Anomaly Detection Module</h2>

        {/* Status Card */}
        <Card
          className={`glow-accent-sm p-6 border transition-all mb-6 ${
            isAlert ? "border-destructive/50 bg-destructive/5" : "border-accent/20 bg-card/50"
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg">Current Anomaly Score</h3>
            <div className={`text-3xl font-bold font-mono ${isAlert ? "text-destructive" : "text-accent"}`}>
              {(currentAnomaly * 100).toFixed(1)}%
            </div>
          </div>

          <div className="w-full bg-card/50 rounded-full h-2 overflow-hidden border border-border">
            <div
              className={`h-full transition-all ${isAlert ? "bg-destructive" : "bg-accent"}`}
              style={{ width: `${currentAnomaly * 100}%` }}
            />
          </div>

          <div className="mt-4 flex items-center gap-2">
            <span
              className={`inline-block w-2 h-2 rounded-full ${isAlert ? "bg-destructive animate-pulse" : "bg-green-400"}`}
            />
            <span className={`text-sm font-semibold ${isAlert ? "text-destructive" : "text-green-400"}`}>
              {isAlert ? "⚠️ ALERT THRESHOLD EXCEEDED" : "✓ Normal Operations"}
            </span>
          </div>
        </Card>

        {/* Anomaly Chart */}
        <Card className="glow-accent-sm p-6 border-accent/20 bg-card/50 mb-6">
          <h3 className="font-semibold text-lg mb-4">Anomaly Score Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={anomalyData}>
              <defs>
                <linearGradient id="colorAnomaly" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.1)" />
              <XAxis dataKey="time" stroke="rgba(139, 92, 246, 0.3)" />
              <YAxis stroke="rgba(139, 92, 246, 0.3)" domain={[0, 1]} />
              <Tooltip
                contentStyle={{ backgroundColor: "#1a1a2e", border: "1px solid rgba(139, 92, 246, 0.3)" }}
                labelStyle={{ color: "#8b5cf6" }}
                formatter={(value: number) => [(value * 100).toFixed(1) + "%", "Score"]}
              />
              <ReferenceLine
                y={0.7}
                stroke="rgba(239, 68, 68, 0.5)"
                strokeDasharray="5 5"
                label={{
                  value: "Alert Threshold",
                  position: "insideTopRight",
                  fill: "rgba(239, 68, 68, 0.7)",
                  offset: -10,
                }}
              />
              <Area
                type="monotone"
                dataKey="anomalyScore"
                stroke="#8b5cf6"
                fillOpacity={1}
                fill="url(#colorAnomaly)"
                isAnimationActive={true}
              />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Detection Logic */}
        <Card className="glow-accent-sm p-6 border-accent/20 bg-card/50">
          <h3 className="font-semibold text-lg mb-4">Detection Logic (Python)</h3>
          <pre className="bg-black/30 rounded p-4 overflow-x-auto text-sm font-mono text-green-400 text-balance">
            <code>{detectionCode}</code>
          </pre>
        </Card>
      </div>
    </div>
  )
}
