"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Clock } from "lucide-react"

interface Alert {
  id: string
  type: "critical" | "warning" | "info"
  title: string
  description: string
  timestamp: Date
  status: "active" | "acknowledged" | "resolved"
  confidence: number
}

export default function AlertManager() {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      type: "critical",
      title: "Group Detection in Restricted Zone",
      description: "4 individuals detected in Building C basement. No valid access records.",
      timestamp: new Date(Date.now() - 2 * 60000),
      status: "active",
      confidence: 0.98,
    },
    {
      id: "2",
      type: "warning",
      title: "Unusual Movement Pattern",
      description: "Anomalous behavior detected on East Campus. Confidence: 78%",
      timestamp: new Date(Date.now() - 15 * 60000),
      status: "acknowledged",
      confidence: 0.78,
    },
    {
      id: "3",
      type: "info",
      title: "System Status: All Sensors Online",
      description: "All 24 campus sensors reporting normal operation.",
      timestamp: new Date(Date.now() - 45 * 60000),
      status: "resolved",
      confidence: 1.0,
    },
  ])

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        const newAlert: Alert = {
          id: Date.now().toString(),
          type: Math.random() > 0.5 ? "critical" : "warning",
          title: Math.random() > 0.5 ? "Potential Security Incident" : "System Alert",
          description: "New detection from LangGraph pipeline analysis.",
          timestamp: new Date(),
          status: "active",
          confidence: Math.random() * 0.3 + 0.7,
        }
        setAlerts((prev) => [newAlert, ...prev.slice(0, 9)])
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const handleAcknowledge = (id: string) => {
    setAlerts((prev) => prev.map((alert) => (alert.id === id ? { ...alert, status: "acknowledged" } : alert)))
  }

  const handleResolve = (id: string) => {
    setAlerts((prev) => prev.map((alert) => (alert.id === id ? { ...alert, status: "resolved" } : alert)))
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "critical":
        return <AlertCircle className="w-5 h-5" />
      case "warning":
        return <Clock className="w-5 h-5" />
      default:
        return <CheckCircle className="w-5 h-5" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "border-destructive/50 bg-destructive/5"
      case "acknowledged":
        return "border-yellow-500/50 bg-yellow-500/5"
      case "resolved":
        return "border-green-500/50 bg-green-500/5"
      default:
        return "border-border"
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Alert Management System</h2>
          <div className="text-sm text-muted-foreground">
            Total: <span className="font-semibold text-foreground">{alerts.length}</span> | Active:{" "}
            <span className="font-semibold text-destructive">{alerts.filter((a) => a.status === "active").length}</span>
          </div>
        </div>

        <div className="space-y-4">
          {alerts.map((alert) => (
            <Card key={alert.id} className={`p-6 border transition-all ${getStatusColor(alert.status)}`}>
              <div className="flex items-start gap-4">
                <div
                  className={`text-${alert.type === "critical" ? "destructive" : alert.type === "warning" ? "yellow-500" : "green-400"} mt-1`}
                >
                  {getIcon(alert.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold">{alert.title}</h3>
                    <span
                      className={`inline-block w-2 h-2 rounded-full ${
                        alert.status === "active"
                          ? "bg-destructive animate-pulse"
                          : alert.status === "acknowledged"
                            ? "bg-yellow-500"
                            : "bg-green-400"
                      }`}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{alert.description}</p>

                  <div className="flex items-center justify-between flex-wrap gap-2 text-xs text-muted-foreground">
                    <div className="flex gap-4">
                      <span>
                        Confidence:{" "}
                        <span className="font-mono font-semibold">{(alert.confidence * 100).toFixed(0)}%</span>
                      </span>
                      <span>{alert.timestamp.toLocaleTimeString()}</span>
                    </div>

                    <div className="flex gap-2">
                      {alert.status === "active" && (
                        <>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleAcknowledge(alert.id)}
                            className="text-xs"
                          >
                            Acknowledge
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => handleResolve(alert.id)} className="text-xs">
                            Resolve
                          </Button>
                        </>
                      )}
                      {alert.status === "acknowledged" && (
                        <Button size="sm" variant="ghost" onClick={() => handleResolve(alert.id)} className="text-xs">
                          Mark Resolved
                        </Button>
                      )}
                      {alert.status === "resolved" && (
                        <span className="inline-flex items-center gap-1 text-green-400">
                          <CheckCircle className="w-4 h-4" /> Resolved
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
