"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"

export default function VideoDetectionPanel() {
  const [videoLoaded, setVideoLoaded] = useState(false)
  const [detections, setDetections] = useState<
    Array<{ id: number; x: number; y: number; label: string; confidence: number }>
  >([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setVideoLoaded(true)
      setIsAnalyzing(true)

      // Simulate video analysis
      setTimeout(() => {
        setDetections([
          { id: 1, x: 30, y: 25, label: "Person", confidence: 0.98 },
          { id: 2, x: 55, y: 40, label: "Person", confidence: 0.96 },
          { id: 3, x: 70, y: 35, label: "Person", confidence: 0.97 },
          { id: 4, x: 45, y: 60, label: "Person", confidence: 0.95 },
        ])
        setIsAnalyzing(false)
      }, 2000)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-6">Video Upload & Real-Time Detection</h2>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Video Player Area */}
          <div className="md:col-span-2">
            <Card className="glow-accent-sm border-accent/20 bg-card/50 p-0 overflow-hidden">
              <div className="relative w-full aspect-video bg-black flex items-center justify-center">
                {!videoLoaded ? (
                  <div className="text-center">
                    <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">Upload CCTV footage to analyze</p>
                    <Button onClick={() => fileInputRef.current?.click()}>Choose Video File</Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="video/*"
                      onChange={handleVideoUpload}
                      className="hidden"
                    />
                  </div>
                ) : (
                  <div className="relative w-full h-full">
                    {/* Video placeholder with detection boxes */}
                    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-black to-slate-900 flex items-center justify-center relative">
                      <div className="text-center z-10">
                        <p className="text-sm text-muted-foreground">Sample CCTV Stream</p>
                      </div>

                      {/* Detection boxes */}
                      {detections.map((det) => (
                        <div
                          key={det.id}
                          className="absolute glow-accent-sm"
                          style={{
                            left: `${det.x}%`,
                            top: `${det.y}%`,
                            width: "120px",
                            height: "150px",
                            border: "2px solid rgba(139, 92, 246, 0.6)",
                            transform: "translate(-50%, -50%)",
                          }}
                        >
                          <div className="absolute -top-6 left-0 bg-accent text-accent-foreground px-2 py-1 rounded text-xs whitespace-nowrap font-mono">
                            {det.label} {(det.confidence * 100).toFixed(0)}%
                          </div>
                        </div>
                      ))}

                      {/* Scan line effect */}
                      {isAnalyzing && <div className="absolute inset-0 scan-line" />}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Detection Stats */}
          <Card className="glow-accent-sm border-accent/20 bg-card/50 p-6">
            <h3 className="font-semibold mb-4">Detection Results</h3>
            <div className="space-y-4">
              <div className="p-4 bg-accent/10 border border-accent/30 rounded">
                <div className="text-2xl font-bold text-accent">{detections.length}</div>
                <div className="text-sm text-muted-foreground">Persons Detected</div>
              </div>

              {detections.length > 0 && (
                <div className="bg-destructive/10 border border-destructive/30 rounded p-3">
                  <p className="text-sm font-semibold text-destructive mb-1">⚠️ Alert Triggered</p>
                  <p className="text-xs text-muted-foreground">
                    {detections.length > 2
                      ? "Group of 3+ individuals detected in restricted zone"
                      : "Individual detected"}
                  </p>
                </div>
              )}

              <div className="pt-4 border-t border-border">
                <div className="text-xs text-muted-foreground mb-3">Average Confidence</div>
                <div className="flex gap-2">
                  {detections.map((det) => (
                    <div
                      key={det.id}
                      className="flex-1 h-8 bg-accent/20 rounded flex items-center justify-center text-xs font-mono text-accent"
                      title={`Person ${det.id}: ${(det.confidence * 100).toFixed(0)}%`}
                    >
                      {(det.confidence * 100).toFixed(0)}%
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
