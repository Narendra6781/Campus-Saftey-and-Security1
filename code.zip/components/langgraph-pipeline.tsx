"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function LangGraphPipeline() {
  const [pipelineData, setPipelineData] = useState([
    { stage: "CCTV Feed", status: "active", latency: 45, confidence: 98 },
    { stage: "Object Detector", status: "active", latency: 120, confidence: 97 },
    { stage: "Group Analyzer", status: "pending", latency: 0, confidence: 0 },
    { stage: "Sensor Fusion", status: "pending", latency: 0, confidence: 0 },
    { stage: "Anomaly Detector", status: "pending", latency: 0, confidence: 0 },
    { stage: "Alert Manager", status: "pending", latency: 0, confidence: 0 },
  ])

  const [throughputData, setThroughputData] = useState(
    Array.from({ length: 12 }, (_, i) => ({
      time: `${i}:00`,
      frames: Math.floor(Math.random() * 3000) + 1500,
    })),
  )

  useEffect(() => {
    const interval = setInterval(() => {
      setPipelineData((prev) => {
        const updated = [...prev]
        // Simulate pipeline progression
        for (let i = 0; i < updated.length - 1; i++) {
          if (updated[i].status === "active" && updated[i + 1].status === "pending") {
            if (Math.random() > 0.6) {
              updated[i + 1].status = "active"
              updated[i + 1].latency = Math.floor(Math.random() * 200) + 50
              updated[i + 1].confidence = Math.floor(Math.random() * 15) + 85
            }
          }
        }
        return updated
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-6">LangGraph Pipeline Architecture</h2>

        {/* Pipeline Visualization */}
        <div className="grid gap-4 mb-8">
          {pipelineData.map((stage, idx) => (
            <div key={idx}>
              <div
                className={`glow-accent-sm p-6 rounded-lg border transition-all ${
                  stage.status === "active"
                    ? "bg-accent/10 border-accent/50 shadow-[0_0_20px_rgba(139,92,246,0.3)]"
                    : "bg-card/50 border-border"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-lg">{stage.stage}</h3>
                  <div className="flex items-center gap-3">
                    <span
                      className={`inline-block w-2 h-2 rounded-full ${
                        stage.status === "active" ? "bg-green-400 pulse" : "bg-gray-600"
                      }`}
                    />
                    <span className="text-xs font-mono text-muted-foreground">{stage.status.toUpperCase()}</span>
                  </div>
                </div>

                {stage.status === "active" && (
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Latency: </span>
                      <span className="font-mono text-accent">{stage.latency}ms</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Confidence: </span>
                      <span className="font-mono text-accent">{stage.confidence}%</span>
                    </div>
                  </div>
                )}
              </div>

              {idx < pipelineData.length - 1 && (
                <div className="flex justify-center py-2">
                  <div
                    className={`w-0.5 h-6 ${
                      stage.status === "active" ? "bg-accent/50" : "bg-border"
                    } transition-colors`}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Throughput Chart */}
      <Card className="glow-accent-sm p-6 border-accent/20 bg-card/50">
        <h3 className="font-semibold text-lg mb-4">Frame Processing Throughput</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={throughputData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.1)" />
            <XAxis dataKey="time" stroke="rgba(139, 92, 246, 0.3)" />
            <YAxis stroke="rgba(139, 92, 246, 0.3)" />
            <Tooltip
              contentStyle={{ backgroundColor: "#1a1a2e", border: "1px solid rgba(139, 92, 246, 0.3)" }}
              labelStyle={{ color: "#8b5cf6" }}
            />
            <Line
              type="monotone"
              dataKey="frames"
              stroke="#8b5cf6"
              strokeWidth={2}
              dot={false}
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>
    </div>
  )
}
