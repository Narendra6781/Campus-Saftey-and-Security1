"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Zap, Camera, Brain, Radio, Shield, AlertCircle } from "lucide-react"

export default function LandingPage({ onStartDemo }: { onStartDemo: () => void }) {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Animated background grid */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(#8b5cf6 1px, transparent 1px), linear-gradient(90deg, #8b5cf6 1px, transparent 1px)",
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      {/* Hero Section */}
      <div className="relative">
        {/* Glow orbs */}
        <div className="absolute top-20 left-1/3 w-96 h-96 bg-purple-500 opacity-5 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute bottom-40 right-1/4 w-80 h-80 bg-blue-500 opacity-5 blur-3xl rounded-full pointer-events-none" />

        {/* Header */}
        <header className="relative px-6 py-8 flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-accent" />
            <span className="text-2xl font-bold text-pretty">CampusGuard AI</span>
          </div>
          <nav className="hidden md:flex gap-8 text-sm">
            <a href="#features" className="hover:text-accent transition">
              Features
            </a>
            <a href="#technology" className="hover:text-accent transition">
              Technology
            </a>
            <a href="#demo" className="hover:text-accent transition">
              Demo
            </a>
          </nav>
        </header>

        {/* Main Hero */}
        <div
          className={`relative px-6 py-24 max-w-7xl mx-auto text-center transition-all duration-1000 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold text-balance mb-6 bg-gradient-to-r from-accent via-purple-400 to-blue-400 bg-clip-text text-transparent">
              Agentic AI Campus Security
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground text-balance max-w-3xl mx-auto mb-8">
              Real-time predictive analytics for campus safety. Detect incidents before they happen using LangGraph
              orchestration and advanced anomaly detection.
            </p>
          </div>

          <Button
            onClick={onStartDemo}
            size="lg"
            className="bg-accent hover:bg-purple-600 text-accent-foreground mb-16 pulse-glow"
          >
            <Zap className="w-4 h-4 mr-2" />
            Start Interactive Demo
          </Button>

          {/* Feature Grid */}
          <div id="features" className="grid md:grid-cols-3 gap-6 my-24">
            <FeatureCard
              icon={<Camera className="w-6 h-6" />}
              title="Real-Time Detection"
              description="Advanced computer vision detects groups and behavioral anomalies in CCTV feeds"
              delay={0}
            />
            <FeatureCard
              icon={<Brain className="w-6 h-6" />}
              title="AI-Powered Analysis"
              description="LangGraph coordinates multi-sensor data fusion for intelligent threat assessment"
              delay={100}
            />
            <FeatureCard
              icon={<Radio className="w-6 h-6" />}
              title="Instant Alerts"
              description="Immediate notifications to security personnel with contextual incident data"
              delay={200}
            />
          </div>
        </div>
      </div>

      {/* System Overview Section */}
      <div id="technology" className="relative px-6 py-24 bg-gradient-to-b from-transparent to-card/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-balance mb-16">Intelligent System Architecture</h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Pipeline Visualization */}
            <div className="space-y-4">
              <div className="space-y-3 glow-accent rounded-lg p-8 bg-card/50 border border-accent/20">
                <PipelineStep label="CCTV Feed" icon="📹" position="left" active={true} />
                <PipelineStep label="Object Detector" icon="🎯" position="center" active={true} />
                <PipelineStep label="Group Analyzer" icon="👥" position="center" active={false} />
                <PipelineStep label="Sensor Fusion" icon="🔗" position="center" active={false} />
                <PipelineStep label="Anomaly Detector" icon="⚡" position="right" active={false} />
              </div>
              <p className="text-sm text-muted-foreground italic">
                LangGraph enables real-time data flow orchestration
              </p>
            </div>

            {/* Description */}
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2 flex items-center gap-2 text-accent">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Multi-Sensor Fusion
                </h3>
                <p className="text-muted-foreground">
                  Combines CCTV, Wi-Fi density, access control logs, and motion sensors for comprehensive threat
                  assessment.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 flex items-center gap-2 text-accent">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Python Anomaly Detection
                </h3>
                <p className="text-muted-foreground">
                  Real-time scoring identifies unusual crowd behavior and potential security incidents with high
                  accuracy.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 flex items-center gap-2 text-accent">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Instant Response
                </h3>
                <p className="text-muted-foreground">
                  Automatic alert generation with detailed context for security teams to respond immediately.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div id="demo" className="relative px-6 py-24">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="glow-accent border-accent/30 p-12 bg-card/50">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-accent" />
            <h2 className="text-3xl font-bold mb-4">See It In Action</h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Experience the full capabilities of our AI-powered campus security system with real-time video analysis,
              threat detection, and integrated alert management.
            </p>
            <Button onClick={onStartDemo} size="lg" className="bg-accent hover:bg-purple-600 text-accent-foreground">
              Launch Demo Now
            </Button>
          </Card>
        </div>
      </div>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
  delay,
}: { icon: React.ReactNode; title: string; description: string; delay: number }) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  return (
    <Card
      className={`glow-accent-sm p-6 border-accent/20 bg-card/50 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
    >
      <div className="text-accent mb-4">{icon}</div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </Card>
  )
}

function PipelineStep({
  label,
  icon,
  position,
  active,
}: { label: string; icon: string; position: string; active: boolean }) {
  return (
    <div
      className={`flex items-center gap-4 p-4 rounded-lg transition-all ${active ? "bg-accent/10 border border-accent/30" : "bg-transparent border border-transparent"}`}
    >
      <div className={`text-2xl ${active ? "opacity-100" : "opacity-50"}`}>{icon}</div>
      <div className="flex-1">
        <p className={`font-mono text-sm ${active ? "text-accent font-semibold" : "text-muted-foreground"}`}>{label}</p>
      </div>
      {position !== "right" && (
        <div className={`text-xl ${active ? "text-accent" : "text-muted-foreground/30"}`}>→</div>
      )}
    </div>
  )
}
