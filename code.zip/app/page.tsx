"use client"

import { useState } from "react"
import LandingPage from "@/components/landing-page"
import DashboardPage from "@/components/dashboard-page"

export default function Home() {
  const [showDemo, setShowDemo] = useState(false)

  return showDemo ? (
    <DashboardPage onBack={() => setShowDemo(false)} />
  ) : (
    <LandingPage onStartDemo={() => setShowDemo(true)} />
  )
}
